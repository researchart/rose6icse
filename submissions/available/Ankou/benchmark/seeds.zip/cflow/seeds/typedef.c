typedef struct x {
	char **foo;
} X;
typedef struct y {
	char **foo;
} Y;
