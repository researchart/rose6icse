int main()
{
        hello(NULL);
        printf("Hello\n");
}
hello(const char *data)
{
        printf("Hello\n");
}

