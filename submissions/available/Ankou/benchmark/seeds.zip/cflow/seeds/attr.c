extern main() __attribute__((noreturn));

main()
{
     foo();
}

