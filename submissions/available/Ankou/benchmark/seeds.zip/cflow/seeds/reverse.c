foo()
{
}

bar()
{
     foo();
}

main()
{
     bar();
     foo();
}

