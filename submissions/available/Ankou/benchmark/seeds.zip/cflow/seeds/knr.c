main(argc, argv)
int argc;
char *argv[]
{
	foo(argc);
}

void
foo(x)
TYPE x;
{
	x;
}

